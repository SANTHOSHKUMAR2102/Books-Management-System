import { Component, h } from "@stencil/core"; 

@Component({
  tag: "about-page",
  styleUrl: "about.css",
  shadow: true
})
export class AboutPage {
  handleBack() {
    window.history.back();
  }

  render() {
    return (
      <div>
        <nav>
          <h2>Book Management System</h2>
          <div>
            <button onClick={() => this.handleBack()}>BACK</button>
          </div>
        </nav>
        <div class="container">
          <h2>About This Application</h2>
          <p>Welcome to the Book Management System! This application provides the following features:</p>
          <ul>
            <li><strong>Book Management:</strong> Users can add, view, edit, and delete book entries. Manage your book collection efficiently with a user-friendly interface.</li>
            <li><strong>Authentication:</strong> User login and session management are implemented using session storage to ensure secure access to the application.</li>
            <li><strong>Data Storage:</strong> Book data is persisted across sessions using local storage, so your book collection remains intact even after you close the application.</li>
          </ul>
          <p>Thank you for using our application. We hope you find it helpful in managing your book collection!</p>
        </div>
      </div>
    );
  }
}
