# about-page



<!-- Auto Generated Below -->


## Dependencies

### Used by

 - [app-router](../app-router)

### Graph
```mermaid
graph TD;
  app-router --> about-page
  style about-page fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
