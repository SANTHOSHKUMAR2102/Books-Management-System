import { Component, h } from "@stencil/core";

@Component({
  tag: "home-page",
  styleUrl: "home-page.css",
  shadow: true
})

export class HomePage{
  handleClick(content: string){
    location.href = content === "login" ? "/login-page" : content === "signup" ? "/signup-page" : content === "about" ? "/about" : "";
  }
  render(){
    return[

      <nav>
        <h2>Book Management System</h2>
        <div>
          <button onClick={this.handleClick.bind(this, "signup")}>SIGNUP</button>
          <button onClick={this.handleClick.bind(this, "about")}>ABOUT</button>
        </div>
      </nav>,

      <div class="container">
        <h1>Welcome!! Buddy</h1>         
        <button onClick={this.handleClick.bind(this, "login")}>LOGIN</button>
      </div>

    ]
  }
}