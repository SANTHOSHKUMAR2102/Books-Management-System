import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'user-login',
  styleUrl: 'user-login.css',
  shadow: true,
})
export class UserLogin {
  @State() userMail: string = '';
  @State() password: string = '';
  @State() userErrorMsg: string = '';
  @State() passwordErrorMsg: string = '';
  @State() errorMsg: string = '';

  handleSubmit(event: Event) {
    event.preventDefault();
    let users = JSON.parse(localStorage.getItem("userDetails"));
    users.forEach(element => {
      this.userErrorMsg = this.userMail === "" ? "*uerMail is Required" : "";
      this.passwordErrorMsg = this.password === "" ? "*Password is not correct" : "";
      if(this.userMail !== element.email || this.password !== element.password){
        
        this.errorMsg = "uerMail or Password is Incorrect"
          
      }else{
        sessionStorage.setItem('addToken', JSON.stringify({ userMail: this.userMail, userPassword: this.password }));
    
          this.handleDirectory();
          this.userMail = '';
          this.password = '';
          this.errorMsg = '';
      }
    });
    
    
  }

  handleDirectory() {
    const thereToken = sessionStorage.getItem('addToken');
    if (thereToken) {
      location.href = '/dash';
    } else {
      console.log('not there');
    }
  }
  handleNavClick(content: string){
    location.href = content === "home" ? "/" : content === "about" ? "/about" : "";
  }

  render() {
    return [
      <nav>
        <h2>Book Management System</h2>
        <div>
          <button onClick={this.handleNavClick.bind(this, "home")}>HOME</button>
          <button onClick={this.handleNavClick.bind(this, "about")}>ABOUT</button>
        </div>
      </nav>,
      <div class="login">
        <form onSubmit={event => this.handleSubmit(event)}>
          <h2>Login Page</h2>
          <p class="incorrect-err">{this.errorMsg}</p>
          <label htmlFor="uerMail">Email: </label>
          <input type="text" placeholder="Enter your mail ID" value={this.userMail} onInput={event => (this.userMail = (event.target as HTMLInputElement).value)} /> <br />
          <p class="error-msg">{this.userErrorMsg}</p>
          <label htmlFor="password">Password: </label>
          <input type="password" placeholder="Enter your Password" value={this.password} onInput={event => (this.password = (event.target as HTMLInputElement).value)} />
          <br />
          <p class="error-msg">{this.passwordErrorMsg}</p>
          <button type="submit">Login</button>
          <p class="tag-line">Don't have an acount? <a href="/signup-page">SIGN UP</a></p>
        </form>
      </div>,
    ];
  }
}
