import { Component, h } from "@stencil/core";
import { createRouter, Route } from 'stencil-router-v2';

const Router = createRouter();

@Component({
  tag: "app-router"
})

export class AppRouter{
  render(){
    return(
      <div>
        <Router.Switch>
          <Route path="/">
            <home-page></home-page>
          </Route>
          <Route path="/login-page">
            <user-login></user-login>
          </Route>
          <Route path="/signup-page">
            <signin-page></signin-page>
          </Route>
          <Route path="/dash">
            <my-dash></my-dash>
          </Route>
          <Route path="/about">
            <about-page></about-page>
          </Route>

        </Router.Switch>
      </div>
    )
  }
}