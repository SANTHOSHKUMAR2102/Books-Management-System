# app-router



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [home-page](../home-page)
- [user-login](../login)
- [signin-page](../signin)
- [my-dash](../dashbourd)
- [about-page](../about-page)

### Graph
```mermaid
graph TD;
  app-router --> home-page
  app-router --> user-login
  app-router --> signin-page
  app-router --> my-dash
  app-router --> about-page
  style app-router fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
