import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'signin-page',
  styleUrl: 'signin-page.css',
  shadow: true,
})
export class SignPage {
  
  @State() username: string = '';
  @State() email: string = '';
  @State() password: string = '';
  @State() confirmPassword: string = '';

  @State() nameError: string = '';
  @State() emailError: string = '';
  @State() passError: string = '';
  @State() confirmPassError: string = '';

  validateForm() {
    let valid = true;

    this.nameError = this.username === '' ? 'Username is Required' : '';
    if (this.username === '') valid = false;

    this.emailError = !this.email.includes('@') ? 'Invalid Email Address' : '';
    if (this.email === '' || !this.email.includes('@')) valid = false;

    this.passError = this.password.length > 8 ? 'Password must be at least 8 characters' : '';
    if (this.password === '' || this.password.length > 8) valid = false;

    this.confirmPassError = this.confirmPassword === '' ? 'Confirm Password is Required' : this.confirmPassword !== this.password ? 'Passwords do not match' : '';
    if (this.confirmPassword === '' || this.confirmPassword !== this.password) valid = false;

    return valid;
  }

  handleSubmit(event: Event) {
    event.preventDefault();

    if (this.validateForm()) {
      const user = {
        username: this.username,
        email: this.email,
        password: this.password,
      };

      let users: any[] = JSON.parse(localStorage.getItem('userDetails') || '[]');

      users.push(user);

      localStorage.setItem('userDetails', JSON.stringify(users));
      this.username = '';
      this.email = '';
      this.password = '';
      this.confirmPassword = '';

      console.log('User details stored successfully.');
      location.href = "/login-page"
    } else {
      console.error('Form validation failed');
    }
  }

  render() {
    return (
      <div>
        <nav>
          <h2>Book Management System</h2>
          <div>
            <button onClick={() => (window.location.href = '/')}>HOME</button>
            <button>ABOUT</button>
          </div>
        </nav>
        <div class="signin">
          <form onSubmit={event => this.handleSubmit(event)}>
            <h2>Sign Up</h2>
            <label htmlFor="username">Username:</label>
            <input type="text" placeholder="Enter Your Name" value={this.username} onInput={event => (this.username = (event.target as HTMLInputElement).value)} />
            <p class="error-msg">{this.nameError}</p>

            <label htmlFor="email">Email:</label>
            <input type="email" placeholder="Enter Your Email ID" value={this.email} onInput={event => (this.email = (event.target as HTMLInputElement).value)} />
            <p class="error-msg">{this.emailError}</p>

            <label htmlFor="password">Password:</label>
            <input type="password" placeholder="Enter Your Password" value={this.password} onInput={event => (this.password = (event.target as HTMLInputElement).value)} />
            <p class="error-msg">{this.passError}</p>

            <label htmlFor="confirmPassword">Confirm Password:</label>
            <input
              type="password"
              placeholder="Confirm Your Password"
              value={this.confirmPassword}
              onInput={event => (this.confirmPassword = (event.target as HTMLInputElement).value)}
            />
            <p class="error-msg">{this.confirmPassError}</p>

            <button type="submit">SIGN UP</button>

            <p class="tag-line">Already have an acount? <a href="/login-page">LOGIN</a></p>
          </form>
        </div>
      </div>
    );
  }
}
