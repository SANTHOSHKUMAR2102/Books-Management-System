import { Component, h, State } from '@stencil/core';

interface MyBook {
  book: string;
  author: string;
  read: boolean;
}

@Component({
  tag: 'my-dash',
  styleUrl: 'dash.css',
  shadow: true,
})
export class DashBoard {
  @State() library: MyBook[] = [{ book: 'demo', author: 'sds', read: false }];
  @State() bookName: string = '';
  @State() bookAuthor: string = '';
  @State() nameError: string = '';
  @State() authorError: string = '';
  @State() editIndex: number | null = null;
  @State() editName: string = '';
  @State() editAuthor: string = '';
  @State() sessionName: string = ''

  
  

  componentWillLoad() {
    if (!sessionStorage.getItem('addToken')) {
      location.href = '/';
    }
    this.sessionName = JSON.parse(sessionStorage.getItem('addToken')).userMail;
    this.library = JSON.parse(localStorage.getItem(`${this.sessionName}`) || '[]')
  }


  handleLogout() {
    sessionStorage.removeItem('addToken');
    if (!sessionStorage.getItem('addToken')) {
      location.href = '/';
    }
  }

  handleBook(content: string, event: Event) {
    const value = (event.target as HTMLInputElement).value.trim();

    if (content === 'name') {
      this.bookName = value;
    }
    if (content === 'author') {
      this.bookAuthor = value;
    }
  }

  handleAddBook(e: Event) {
    e.preventDefault();
    this.addBook();
  }

  addBook() {
    if (this.bookName === '' || this.bookAuthor === '') {
      this.nameError = this.bookName === '' ? '*Book Name is Required!!' : '';
      this.authorError = this.bookAuthor === '' ? '*Author Name is Required!' : '';
      return;
    }

    const newBook: MyBook = { book: this.bookName, author: this.bookAuthor, read: false };
    // this.library = [...this.library, newBook];
    
    let bookDetail: any[] = JSON.parse(localStorage.getItem(`${this.sessionName}`) || "[]");

    bookDetail.push(newBook);

    localStorage.setItem(`${this.sessionName}`, JSON.stringify(bookDetail));

    this.bookName = '';
    this.bookAuthor = '';
    this.nameError = '';
    this.authorError = '';
    this.componentWillLoad();
  }

  removeBook(index: number) {
    this.library = this.library.filter((_, i) => i !== index);
    localStorage.setItem(`${this.sessionName}`, JSON.stringify(this.library));
  }

  handleRead(index: number) {
    this.library = this.library.map((item, i) => (i === index ? { ...item, read: !item.read } : item));
    localStorage.setItem(`${this.sessionName}`, JSON.stringify(this.library));
  }

  startEdit(index: number) {
    this.editIndex = index;
    this.editName = this.library[index].book;
    this.editAuthor = this.library[index].author;
  }

  handleEdit(e: Event) {
    e.preventDefault();
    this.library = this.library.map((item, i) => (i === this.editIndex ? { ...item, book: this.editName, author: this.editAuthor } : item));
    this.editIndex = null;
    localStorage.setItem(`${this.sessionName}`, JSON.stringify(this.library));
  }

  handleCancel() {
    this.editIndex = null;
    this.editName = '';
    this.editAuthor = '';
  }

  render() {
    return (
      <div>
        <nav>
          <h2>Books Management System</h2>
          <button onClick={this.handleLogout.bind(this)}>Logout</button>
        </nav>

        <form onSubmit={event => this.handleAddBook(event)} class="add-form">
          <label htmlFor="bookName">Book Name:</label>
          <input id="bookName" type="text" placeholder="Enter Your Book Name..." value={this.bookName} onInput={event => this.handleBook('name', event)} />
          <p class="error-msg">{this.nameError}</p>

          <label htmlFor="authorName">Author Name:</label>
          <input id="authorName" type="text" placeholder="Enter the Author Name..." value={this.bookAuthor} onInput={event => this.handleBook('author', event)} />
          <p class="error-msg">{this.authorError}</p>

          <button type="submit">Add Book</button>
        </form>

        <div>
          <h2>Books List</h2>
          {this.library.map((item, index) => (
            <div key={index} class="d-books">
              {this.editIndex === index ? (
                <form onSubmit={event => this.handleEdit(event)} class="edit-form">
                  <input type="text" value={this.editName} onInput={event => (this.editName = (event.target as HTMLInputElement).value.trim())} />
                  <input type="text" value={this.editAuthor} onInput={event => (this.editAuthor = (event.target as HTMLInputElement).value.trim())} />
                  <div>
                    <button type="submit" class="save-btn">
                      Save
                    </button>
                    <button onClick={this.handleCancel.bind(this)} class="cancel-btn">
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div class="showing">
                  <p style={{ textDecoration: item.read ? 'line-through' : '' }}>
                    {item.book} by {item.author}
                  </p>
                  <div>
                    <button class="read-btn" onClick={this.handleRead.bind(this, index)}>
                      {item.read ? 'Mark As Unread' : 'Mark As Read'}{' '}
                    </button>
                    <button onClick={this.removeBook.bind(this, index)} class="remove-btn">
                      Remove
                    </button>
                    <button class="edit-btn" onClick={this.startEdit.bind(this, index)}>
                      Edit
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }
}
