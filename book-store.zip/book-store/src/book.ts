export class Book {
  constructor(public book: string, public author: string, public read = false) {
  }
}
