export class Library {
  books = [];

  addBook(book: string, author: string) {
    this.books.push({book, author});
  }

  getBooks(){
    return this.books;
  }
}
